<!DOCTYPE html>
<html lang="de">
    <head>
        <style>
            html, body {
                background: #CCC;
            }
        </style>
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="#">Menu 1</a></li>
                <li><a href="#">Menu 2</a></li>
                <li><a href="#">Menu 3</a></li>
            </ul>
        </nav>
        <h1>Hallo WWI2020a</h1>
        <hr />
        <?php echo $this->renderView(); ?>
        <hr />
    </body>
</html>