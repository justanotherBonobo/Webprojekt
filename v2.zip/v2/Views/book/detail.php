<h2>Buch DetailSeite</h2>

<!--
    TODO: render book details
-->